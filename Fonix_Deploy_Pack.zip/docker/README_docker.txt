# Docker deploy

Fájlok:
- Dockerfile
- docker-compose.yml

Előkészítés:
- A projekt gyökerében legyen ott a `server/app.py` (FastAPI app).

Build & run (a `deploy/docker` mappából vagy a projekt gyökeréből):
  docker compose -f deploy/docker/docker-compose.yml up -d --build

Állapot:
  docker ps
  docker logs -f fonix_api

Leállítás:
  docker compose -f deploy/docker/docker-compose.yml down
