# systemd user service (Linux)

1) Másold be a szolgáltatás fájlt:
   mkdir -p ~/.config/systemd/user
   cp fonix.service ~/.config/systemd/user/

2) Töltsd újra a user daemon-t:
   systemctl --user daemon-reload

3) Indítás és engedélyezés bootnál:
   systemctl --user start fonix
   systemctl --user enable fonix

4) Állapot/napló:
   systemctl --user status fonix
   journalctl --user -u fonix -f

Megjegyzés: Feltételezi, hogy a projekt a ~/FonixProjekt alatt van, a venv pedig ~/FonixProjekt/.venv.
