#!/usr/bin/env bash
# Watchdog: ha az endpoint nem él, újraindítja a systemd user szolgáltatást.
set -euo pipefail
SERVICE="${1:-fonix}"
URL="${2:-http://127.0.0.1:8000/}"

if curl -fsS "$URL" >/dev/null; then
  echo "[OK] ${URL} up"
  exit 0
fi

echo "[WARN] ${URL} down, restarting $SERVICE ..." >&2
systemctl --user restart "$SERVICE"
