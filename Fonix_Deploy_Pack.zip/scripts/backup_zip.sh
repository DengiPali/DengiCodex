#!/usr/bin/env bash
# Mentés: zip az egész FonixProjekt mappáról + opcionális feltöltés (helyőrző).
set -euo pipefail
SRC="${1:-$HOME/FonixProjekt}"
DST_DIR="${2:-$HOME/FonixBackups}"
STAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$DST_DIR"
ZIP="$DST_DIR/fonix_${STAMP}.zip"

echo "[*] Zippelés: $SRC -> $ZIP"
cd "$SRC/.."
zip -r "$ZIP" "$(basename "$SRC")" >/dev/null

# Feltöltési helyőrző (például rclone)
# Példa: rclone copy "$ZIP" remote:backup/fonix
if command -v rclone >/dev/null 2>&1; then
  echo "[*] rclone feltöltés…"
  rclone copy "$ZIP" "remote:backup/fonix" || echo "[WARN] rclone feltöltés sikertelen (konfigurálatlan?)"
else
  echo "[INFO] rclone nincs telepítve. ZIP elkészült lokálisan: $ZIP"
fi

echo "[OK] Mentés kész: $ZIP"
