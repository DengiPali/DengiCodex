#!/usr/bin/env bash
# Egyszerű healthcheck: visszatér 0-val, ha az endpoint él.
set -euo pipefail
URL="${1:-http://127.0.0.1:8000/}"
curl -fsS "$URL" >/dev/null && echo "[OK] Alive: $URL" || { echo "[ERR] Down: $URL" >&2; exit 1; }
