
FŐNIX DEPLOY PACK
Készült: 2025-09-20T00:32:37.921779Z

Mire jó?
- Gyors indítás rendszer-szolgáltatásként (systemd user).
- Konténeres futtatás (Docker + compose).
- Healthcheck + watchdog restart script.
- Biztonsági mentés ZIP-be, opcionális rclone feltöltéssel.

Előfeltételek:
- A projekt a saját gépeden: ~/FonixProjekt
- Benne a FastAPI app: server/app.py (példa a korábbi csomagban)

Használat röviden:

[systemd user]
  mkdir -p ~/.config/systemd/user
  cp deploy/systemd-user/fonix.service ~/.config/systemd/user/
  systemctl --user daemon-reload
  systemctl --user start fonix
  systemctl --user enable fonix

[Docker]
  docker compose -f deploy/docker/docker-compose.yml up -d --build

[Healthcheck]
  bash deploy/scripts/healthcheck.sh http://127.0.0.1:8000/

[Watchdog cron példa (5 percenként)]
  crontab -e
  */5 * * * * XDG_RUNTIME_DIR=/run/user/$(id -u) bash ~/FonixProjekt/deploy/scripts/watchdog_restart.sh fonix http://127.0.0.1:8000/

[Backup]
  bash deploy/scripts/backup_zip.sh "$HOME/FonixProjekt" "$HOME/FonixBackups"
