Jegyzetek a DengiCodexhez.
